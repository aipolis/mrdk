import { fetchHistory } from './app.js'
import { getDisplayLevel } from './theme.js'

const $ = (sel) => document.querySelector(sel)

function esc(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
}

function renderList(list) {
  const tbody = $('#historyBody')
  if (!tbody) return
  if (!list?.length) {
    tbody.innerHTML = '<tr><td colspan="4" class="empty">暂无历史数据</td></tr>'
    return
  }
  tbody.innerHTML = list.map((item) => {
    const level = getDisplayLevel(item.score)
    return `
      <tr>
        <td>${esc(item.date)}</td>
        <td class="score ${level.class}">${esc(item.score)}</td>
        <td class="level ${level.class}">${esc(item.level || level.label)}</td>
        <td>${esc(item.indexChg != null ? item.indexChg : '--')}</td>
      </tr>
    `
  }).join('')
}

export async function loadHistoryPage() {
  $('#historyStatus').textContent = '加载中…'
  $('#historyStatus').className = 'status-bar'
  try {
    const data = await fetchHistory(30)
    const list = (data && data.list) || data || []
    renderList(Array.isArray(list) ? list : [])
    $('#historyStatus').textContent = `共 ${Array.isArray(list) ? list.length : 0} 条记录`
    $('#historyStatus').className = 'status-bar ok'
  } catch (err) {
    $('#historyStatus').textContent = err?.message || '加载失败'
    $('#historyStatus').className = 'status-bar err'
  }
}

export function initHistoryPage() {
  $('#refreshBtn')?.addEventListener('click', () => loadHistoryPage())
  loadHistoryPage()
}
